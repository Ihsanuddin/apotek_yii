<?php
return array(
	'No matches found' => 'Nenhum resultado encontrado',
	'Please enter {chars} more characters' => 'Por favor, digite mais {chars} caracteres',
	'You can only select {count} items' => 'Você só pode selecionar {count} elementos',
	'Loading more results...' => 'Carregando mais resultados...',
	'Searching...' => 'Buscando...',
);
