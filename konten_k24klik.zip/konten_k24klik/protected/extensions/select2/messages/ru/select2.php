<?php
return array(
	'No matches found' => 'Пусто',
	'Please enter {chars} more characters' => 'Необходимо ввести еще {chars} символов',
	'Please enter {chars} less characters' => 'Введите на {chars} символов меньше',
	'You can only select {count} items' => 'Вы можете выбрать не более {count} элементов',
	'Loading more results...' => 'Загрузка...',
	'Searching...' => 'Поиск...',
);
