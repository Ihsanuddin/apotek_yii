<?php
return array(
	'No matches found' => 'No se han encontrado resultados',
	'Please enter {chars} more characters' => 'Por favor, tipé {chars} caracteres más',
	'You can only select {count} items' => 'Solo puede seleccionar {count} elementos',
	'Loading more results...' => 'Cargando más resultados...',
	'Searching...' => 'Buscando...',
);
