-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2017 at 05:48 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voucher`
--

-- --------------------------------------------------------

--
-- Table structure for table `prev_voucher`
--

CREATE TABLE `prev_voucher` (
  `id` int(11) NOT NULL,
  `voucher_name` varchar(256) NOT NULL,
  `image` varchar(256) NOT NULL,
  `image_voucher` varchar(256) NOT NULL,
  `csv_file` varchar(256) NOT NULL,
  `coor_x` int(11) NOT NULL,
  `coor_y` int(11) NOT NULL,
  `font_color` varchar(100) NOT NULL,
  `font_size` int(11) NOT NULL,
  `font_style` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prev_voucher`
--

INSERT INTO `prev_voucher` (`id`, `voucher_name`, `image`, `image_voucher`, `csv_file`, `coor_x`, `coor_y`, `font_color`, `font_size`, `font_style`) VALUES
(1, 'test', '20170302043808voucher.jpg', '56TEST4792cjTK24120170302043808.jpg', '', 600, 700, 'black', 30, 'LemonMilk'),
(2, 'test2', '213070643320170228022506voucher.jpg', '56TEST4792cjT4720170228022506.jpg', '', 800, 900, 'black', 30, 'noodle_oblique'),
(3, 'test3', '', '56TEST4792cjT47320170228032904.jpg', '', 800, 700, 'white', 30, 'LemonMilk'),
(4, 'test3', '213070643320170228035647voucher.jpg', '56TEST4792cjT4720170228035647.jpg', '', 900, 900, 'black', 30, 'LemonMilk'),
(5, 'test5', '20170302035410voucher.jpg', '56TEST4792cjTK24520170302035410.jpg', '20170302035506test.csv', 700, 600, 'black', 30, 'LemonMilk'),
(6, 'final', '20170302045855voucher.jpg', '56TEST4792cjTK24620170302050512.jpg', '20170302045855test.csv', 1600, 900, '#000000', 30, 'LemonMilk');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `prev_voucher`
--
ALTER TABLE `prev_voucher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `prev_voucher`
--
ALTER TABLE `prev_voucher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
