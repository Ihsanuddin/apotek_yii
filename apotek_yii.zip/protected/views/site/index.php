<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

<p>Selamat Datang di Halaman Admin</p>

<p>Untuk dapat mengakses, anda diharuskan untuk login terlebih dahulu</p>
<ul>
	<li>Username: <code>"apotek"</code></li>
	<li>Password: <code>"apotek"</code></li>
</ul>

<p>Thanks ^_^</p>
